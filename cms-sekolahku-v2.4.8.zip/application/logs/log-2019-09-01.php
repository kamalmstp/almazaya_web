<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-01 20:59:32 --> Severity: error --> Exception: Class 'Faker\Factory' not found /home/antonsofyan/public_html/cms-sekolahku/application/controllers/Dummy.php 38
